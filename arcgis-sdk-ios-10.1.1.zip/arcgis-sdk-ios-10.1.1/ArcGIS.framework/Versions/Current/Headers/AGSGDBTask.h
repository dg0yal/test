/*
 COPYRIGHT 2013 ESRI
 
 TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
 Unpublished material - all rights reserved under the
 Copyright Laws of the United States and applicable international
 laws, treaties, and conventions.
 
 For additional information, contact:
 Environmental Systems Research Institute, Inc.
 Attn: Contracts and Legal Services Department
 380 New York Street
 Redlands, California, 92373
 USA
 
 email: contracts@esri.com
 */

@class AGSTask;
@class AGSGeometry;
@class AGSGDBGenerateParameters;
@class AGSGDBServiceInfo;
@class AGSGDBGeodatabase;
@protocol AGSCancellable;


/** @file AGSGDBTask.h */ //Required for Globals API doc

/** @brief
 
 @define{AGSGDBTask.h, ArcGIS}
 @since
 */
@interface AGSGDBTask : AGSTask

#warning if the response takes longer than the interval, you can end up with completed status being called several times
@property (nonatomic, assign) NSTimeInterval interval;

@property (nonatomic, strong) AGSGDBServiceInfo *featureServiceInfo;

@property (nonatomic, copy) void (^loadCompletion)(NSError *error);

#pragma mark replica list

-(NSOperation*)queryReplicasWithCompletion:(void (^)(NSArray *replicas, NSError *error))completionBlock;

#pragma mark create replica

/* this one doesn't return an operation because since it takes in completion block, that would be associated with
 the returned NSOperation, which is really completed when the jobStartedBlock is fired.
 */
-(void)generateGeodatabaseReplicaWithParameters:(AGSGDBGenerateParameters *)params
                                     jobStarted:(AGSGDBJobStartedBlock)jobStartedBlock
                                         status:(AGSGDBTaskStatusBlock)statusBlock;
#warning Let's talk about this and discuss consolidating and returning id<AGSCancellable>
-(NSOperation*)generateGeodatabaseReplicaWithParameters:(AGSGDBGenerateParameters *)params
                                             jobStarted:(AGSGDBJobStartedBlock)jobStartedBlock;

-(void)scheduleStatusChecksForJobId:(NSString *)jobId
                             status:(AGSGDBTaskStatusBlock)statusBlock;

-(void)unscheduleStatusChecksForJobId:(NSString *)jobId;

-(void)checkStatusForJobId:(NSString *)jobId
                    status:(AGSGDBTaskStatusBlock)statusBlock;

#warning [OFFLINE] need cancel method
//-(void)cancelJobId:...

#pragma mark fetch replica

-(NSOperation*)fetchGeodatabaseAtURL:(NSURL *)replicaUrl
                          saveToPath:(NSString *)path
                          completion:(void (^)(NSError* error))completionBlock;

#pragma mark sync replica

#warning I think we can get rid of the completionBlock
-(id<AGSCancellable>)syncGeodatabase:(AGSGDBGeodatabase*)geodatabase
                          jobStarted:(AGSGDBJobStartedBlock)jobStartedBlock
                              status:(AGSGDBTaskStatusBlock)status
                          completion:(void (^)(NSError* error))completionBlock;


-(id<AGSCancellable>)fetchAndApplyServerDeltasAtURL:(NSURL*)url forGeodatabase:(AGSGDBGeodatabase*)geodatabase completion:(void (^)(NSError *error))completionBlock;

@end


@interface AGSGDBTask (DebugSync)

/** Delta files will be created here named with <epoch time>.geodatabase
 //
 // TODO: synchronize in/out deltas names with server terminology
 */
@property (nonatomic, copy, readonly) NSString *deltaDirectory;

//
// if NO, will leave the deltas on the device for debugging
@property (nonatomic, assign) BOOL deleteDeltas;

@end

