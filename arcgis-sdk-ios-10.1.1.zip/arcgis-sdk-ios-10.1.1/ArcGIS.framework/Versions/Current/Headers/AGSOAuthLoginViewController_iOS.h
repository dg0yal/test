/*
 COPYRIGHT 2013 ESRI
 
 TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
 Unpublished material - all rights reserved under the
 Copyright Laws of the United States and applicable international
 laws, treaties, and conventions.
 
 For additional information, contact:
 Environmental Systems Research Institute, Inc.
 Attn: Contracts and Legal Services Department
 380 New York Street
 Redlands, California, 92373
 USA
 
 email: contracts@esri.com
 */

#if TARGET_OS_MAC && (!TARGET_OS_IPHONE)
#import <Cocoa/Cocoa.h>
#import <WebKit/WebKit.h>
#endif

/*@file AGSOAuthLoginViewController.h */

@class AGSCredential;

/** @brief A view controller to facilitate the retrieval of a token via OAuth2.
 
 @agssince{10.2, 10.2}
 */
@interface AGSOAuthLoginViewController : UIViewController

/** The URL of the portal to authenticate against.
 @agssince {10.2, 10.2}
 */
@property (nonatomic, copy, readonly) NSURL *URL;

/** Block called when the user either successfully logs in or explicitly cancels the login. This is the point
 at which the login view controller should be dismissed.
 @param credential A credential created from the response of the OAuth2 login page.
 @param error The error encountered when attempting to retrieve an OAuth2 token. If nil, then a
 credential was successfully populated.
 @agssince {10.2, 10.2}
 */
@property (nonatomic, copy) void (^completion)(AGSCredential *credential, NSError *error);

/**
 @param url The URL for the portal in which to authenticate against.
 @param clientId The clientId for the application registered with the portal.
 @agssince {10.2, 10.2}
 */
- (id)initWithPortalURL:(NSURL*)url clientId:(NSString*)clientId;

@end
