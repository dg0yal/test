/*
 COPYRIGHT 2013 ESRI
 
 TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
 Unpublished material - all rights reserved under the
 Copyright Laws of the United States and applicable international
 laws, treaties, and conventions.
 
 For additional information, contact:j
 Environmental Systems Research Institute, Inc.
 Attn: Contracts and Legal Services Department
 380 New York Street
 Redlands, California, 92373
 USA
 
 email: contracts@esri.com
 */

/** @file AGSFeatureLayerProtocol.h */ //Required for Globals API doc

/** @brief
 
 @define{AGSFeatureLayerProtocol.h, ArcGIS}
 @since 
 */
@class AGSRenderer;
@class AGSEditFieldsInfo;
@protocol AGSFeature;

@protocol AGSFeatureSourceInfo <NSObject>

@property (nonatomic, readonly) AGSGeometryType geometryType; 
@property (nonatomic, copy, readonly) NSString *displayField;
@property (nonatomic, copy, readonly) NSArray *fields;
@property (nonatomic, copy, readonly) NSString *objectIdField;
@property (nonatomic, copy, readonly) NSString *typeIdField;
@property (nonatomic, copy, readonly) NSArray *types;
@property (nonatomic, copy, readonly) NSArray *templates;
@property (nonatomic, strong, readonly) AGSRenderer *renderer;
@property (nonatomic, strong, readonly) AGSEditFieldsInfo *editFieldsInfo;
@property (nonatomic, assign, readonly) BOOL hasAttachments;
@property (nonatomic, assign, readonly) BOOL isTableOnly;

@property (nonatomic, assign, readonly) BOOL canCreate;
@property (nonatomic, assign, readonly) BOOL canUpdate;
@property (nonatomic, assign, readonly) BOOL canDelete;
@property (nonatomic, assign, readonly) BOOL canUpdateGeometry;

- (BOOL)canUpdateFeature:(id<AGSFeature>)feature;
- (BOOL)canDeleteFeature:(id<AGSFeature>)feature;

-(long long)objectIdForFeature:(id<AGSFeature>)feature;
-(NSString*)editSummaryForFeature:(id<AGSFeature>)feature;

@end
