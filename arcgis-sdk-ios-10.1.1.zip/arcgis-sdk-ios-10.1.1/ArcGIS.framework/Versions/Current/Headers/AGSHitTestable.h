/*
 COPYRIGHT 2013 ESRI
 
 TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
 Unpublished material - all rights reserved under the
 Copyright Laws of the United States and applicable international
 laws, treaties, and conventions.
 
 For additional information, contact:
 Environmental Systems Research Institute, Inc.
 Attn: Contracts and Legal Services Department
 380 New York Street
 Redlands, California, 92373
 USA
 
 email: contracts@esri.com
 */

@protocol AGSLayerCalloutDelegate;

@protocol AGSHitTestable <NSObject>

/** Property that determines if the layer allows it to be hit tested or if it is bypassed.
 @agssince{10.2, 10.2}
 */
@property (nonatomic, assign) BOOL allowHitTest;

/** Property that determines if the layer allows callouts to be shown for its features.
 @agssince{10.2, 10.2}
 */
@property (nonatomic, assign) BOOL allowCallout;

/** Delegate that allows the layer to react to when a callout is shown for one of it's features.
 @agssince{10.2, 10.2}
 */
@property (nonatomic, weak) id<AGSLayerCalloutDelegate> calloutDelegate;

@end
