/*
 COPYRIGHT 2011 ESRI
 
 TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
 Unpublished material - all rights reserved under the
 Copyright Laws of the United States and applicable international
 laws, treaties, and conventions.
 
 For additional information, contact:
 Environmental Systems Research Institute, Inc.
 Attn: Contracts and Legal Services Department
 380 New York Street
 Redlands, California, 92373
 USA
 
 email: contracts@esri.com
 */




/** @file AGSRouteTask.h */

@class AGSTask;
@class AGSCredential;
@class AGSRouteTaskParameters;
@class AGSRouteTaskResult;
@class AGSNetworkDescription;
@protocol AGSRouteTaskDelegate;

/** @brief A task to compute routes.
 
 Instances of this class represent tasks than can find the best route 
 to get from one location to another or to visit several locations. 
 
 The best route can be the quickest, shortest, or most scenic route, depending on the impedance chosen. 
 If the impedance is time, then the best route is the quickest route. Hence, the best route can
 be defined as the route that has the lowest impedance.
 
 A route task needs a URL to a REST resource that represents a Route layer in a Network Analyst service.
 For example, http://tasks.arcgisonline.com/ArcGIS/rest/services/NetworkAnalysis/ESRI_Route_NA/NAServer/Route

 @see @concept{Route_Task/00pw00000056000000/, Using a Route Task}
 @see @sample{e4fa8dafbe83475882ac9c0fd0a075c7, Routing}
 @agssince{1.8, 10.2}
 */
@interface AGSRouteTask : AGSTask

/** Delegate to be notified when the solve operation has completed or returned 
 an error.
 @agssince{1.8, 10.2}
 */
@property (nonatomic, weak) id<AGSRouteTaskDelegate> delegate;

/** Return an initialized, auto released, route task
 @param url URL to a REST resource that represents a Route layer in a Network Analyst service
 @agssince{1.8, 10.2}
 */
+ (id)routeTaskWithURL:(NSURL *)url;

/** Return an initialized, auto released, route task
 @param url URL to a REST resource that represents a Route layer in a Network Analyst service
 @param cred Credentials need to access the secured service
 @agssince{1.8, 10.2}
 */
+ (id)routeTaskWithURL:(NSURL *)url credential:(AGSCredential*)cred;

/**
 Return an initialized, auto released, route task.
 @param path NSString path to database
 @param network NSString network name
 @param error NSError if error occurs during task creation then this is populated with error
 @agssince{10.2, 10.2}
 */
+ (id)routeTaskWithDatabasePath:(NSString *)path network:(NSString *)network error:(NSError **)error;

/** Solves a route with the given input parameters. It relies on the <i>Solve Route</i> operation
 of the REST resource.
 @param routeParams The input parameters for the solve operation.
 @return <code>NSOperation</code> for the current solve task.
 @agssince{1.8, 10.2}
 @see @c AGSRouteTaskDelegate#routeTask:operation:didSolveWithResult: , method on delegate for success
 @see @c AGSRouteTaskDelegate#routeTask:operation:didFailSolveWithError: , method on delegate for failure
 */
- (NSOperation*)solveWithParameters:(AGSRouteTaskParameters*)routeParams;

/** Retrieves the default route parameters. 
 @return <code>NSOperation</code> for the request.
 @agssince{1.8, 10.2}
 @see @c AGSRouteTaskDelegate#routeTask:operation:didRetrieveDefaultRouteTaskParameters: , method on delegate for success
 @see @c AGSRouteTaskDelegate#routeTask:operation:didFailToRetrieveDefaultRouteTaskParametersWithError: , method on delegate for failure
 */
- (NSOperation*)retrieveDefaultRouteTaskParameters;

/** Retrieves the transportation network description.
 @return <code>NSOperation</code> for the request.
 @agssince{10.2, 10.2}
 @see @c AGSRouteTaskDelegate#routeTask:operation:didRetrieveNetworkDescription: , method on delegate for success
 @see @c AGSRouteTaskDelegate#routeTask:operation:didFailToRetrieveNetworkDescriptionWithError: , method on delegate for failure
 */
- (NSOperation*)retrieveNetworkDescription;

@end

/** @brief A delegate of @c AGSRouteTask.
 
 A protocol which must be adopted by any class wishing to be notified when 
 @c AGSRouteTask completes successfully or encounters an error. An 
 instance of the class must then be set as the delegate of @c AGSRouteTask.
 
 @define{AGSRouteTask.h, ArcGIS}
 @agssince{1.8, 10.2}
 */
@protocol AGSRouteTaskDelegate <NSObject>

@required

/** Tells the delegate that the solve operation completed successfully.
 @param routeTask The route task that performed the solve operation.
 @param op <code>NSOperation</code> that performed the solve task.
 @param routeTaskResult The result of the solve operation.
 @agssince{1.8, 10.2}
 */
- (void)routeTask:(AGSRouteTask*)routeTask operation:(NSOperation*)op didSolveWithResult:(AGSRouteTaskResult*)routeTaskResult;

@optional

/** Tells the delegate that an error was encountered while performing the 
 solve operation.
 @param routeTask The route task that performed the solve operation.
 @param op <code>NSOperation</code> that performed the solve task.
 @param error The error encountered by the solve operation.
 @agssince{1.8, 10.2}
 */
- (void)routeTask:(AGSRouteTask*)routeTask operation:(NSOperation*)op didFailSolveWithError:(NSError*)error;

/** Tells the delegate that the default route parameters were retrieved successfully.
 @param routeTask The route task that performed the request for default parameters.
 @param op <code>NSOperation</code> that performed the request.
 @param routeParams The default route parameters for the task.
 @agssince{1.8, 10.2}
 */
- (void)routeTask:(AGSRouteTask*)routeTask operation:(NSOperation*)op didRetrieveDefaultRouteTaskParameters:(AGSRouteTaskParameters*)routeParams;

/** Tells the delegate that an error was encountered while retrieving the default
 route parameters.
 @param routeTask The route task that performed the request for default parameters.
 @param op <code>NSOperation</code> that performed the request.
 @param error The error encountered by the request.
 @agssince{1.8, 10.2}
 */
- (void)routeTask:(AGSRouteTask*)routeTask operation:(NSOperation*)op didFailToRetrieveDefaultRouteTaskParametersWithError:(NSError*)error;

/** Tells the delegate that the transportation network description wes retrieved successfully.
 @param routeTask The route task that performed the request for network description.
 @param op <code>NSOperation</code> that performed the request.
 @param networkDescription The transportation network description for the task.
 @agssince{10.2, 10.2}
 */
- (void)routeTask:(AGSRouteTask*)routeTask operation:(NSOperation*)op didRetrieveNetworkDescription:(AGSNetworkDescription*)networkDescription;

/** Tells the delegate that an error was encountered while retrieving the transportation
 network description.
 @param routeTask The route task that performed the request for network description.
 @param op <code>NSOperation</code> that performed the request.
 @param error The error encountered by the request.
 @agssince{10.2, 10.2}
 */
- (void)routeTask:(AGSRouteTask*)routeTask operation:(NSOperation*)op didFailToRetrieveNetworkDescriptionWithError:(NSError*)error;

@end

