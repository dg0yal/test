/*
 COPYRIGHT 2013 ESRI
 
 TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
 Unpublished material - all rights reserved under the
 Copyright Laws of the United States and applicable international
 laws, treaties, and conventions.
 
 For additional information, contact:
 Environmental Systems Research Institute, Inc.
 Attn: Contracts and Legal Services Department
 380 New York Street
 Redlands, California, 92373
 USA
 
 email: contracts@esri.com
 */

#import <Foundation/Foundation.h>
@class AGSSpatialReference;
@class AGSEnvelope;
@class AGSMapServiceDocumentInfo;

/** @file AGSGDBServiceInfo.h */ //Required for Globals API doc

/** @brief
 
 @define{AGSGDBServiceInfo.h, ArcGIS}
 @since 
 */
@interface AGSGDBServiceInfo : NSObject <AGSCoding>

/**
 Description from map document properties
 */
@property (nonatomic, copy) NSString *serviceDescription;
@property (nonatomic, assign) BOOL hasVersionedData;
@property (nonatomic, assign) BOOL supportsDisconnectedEditing;
@property (nonatomic, assign) NSUInteger maxRecordCount;
@property (nonatomic, assign) BOOL canCreate;
@property (nonatomic, assign) BOOL canDelete;
@property (nonatomic, assign) BOOL canUpdate;
@property (nonatomic, assign) BOOL queryable;
/** Indicates whether the layer allows geometries of features to be updated.
 You should check this property before allowing the ability to update a feature's geometry in your app.
 @agssince{10.2, 10.2}
 */
@property (nonatomic, assign, readonly) BOOL canUpdateGeometry;
@property (nonatomic, copy) NSString *dataFrameDescription;
@property (nonatomic, copy) NSString *copyrightText;
@property (nonatomic, strong) AGSSpatialReference *spatialReference;
@property (nonatomic, strong) AGSEnvelope *initialExtent;
@property (nonatomic, strong) AGSEnvelope *fullExtent;

@property (nonatomic, assign) AGSUnits units;

@property (nonatomic, strong) AGSMapServiceDocumentInfo *documentInfo;

/** Available layers in the map service and their default visibility as an array of
 @c AGSMapServiceLayerInfo objects.
 @agssince{10.2, 10.2}
 */
@property (nonatomic, copy, readonly) NSArray *layerInfos;

/** Available tables in the map service as an array of
 @c AGSMapServiceTableInfo objects.
 @agssince{10.2, 10.2}
 */
@property (nonatomic, strong, readonly) NSArray *tableInfos;

@property (nonatomic, assign) BOOL enableZDefaults;

/*
 {
 "currentVersion": 10.1,
 "serviceDescription": "Edit parcels, buildings and owner information.",
 "hasVersionedData": false,
 "supportsDisconnectedEditing": true,
 "supportedQueryFormats": "JSON, AMF",
 "maxRecordCount": 1000,
 "capabilities": "Create,Delete,Query,Update,Editing",
 "description": "Street Map USA",
 "copyrightText": "ESRI",
 "spatialReference": {
 "wkid": 4326,
 "latestWkid": 4326
 },
 "initialExtent": {
 "xmin": -109.55,
 "ymin": 25.76,
 "xmax": -86.39,
 "ymax": 49.94,
 "spatialReference": {
 "wkid": 4326,
 "latestWkid": 4326
 }
 },
 "fullExtent": {
 "xmin": -130,
 "ymin": 24,
 "xmax": -65,
 "ymax": 50,
 "spatialReference": {
 "wkid": 4326,
 "latestWkid": 4326
 }
 },
 "allowGeometryUpdates": true,
 "units": "esriDecimalDegrees",
 "documentInfo": {
 "Title": "StreetMap USA",
 "Author": "ESRI Data Team",
 "Comments": "ESRI Data and Maps",
 "Subject": "Street level data for the US",
 "Category": "vector",
 "Keywords": "StreetMap USA"
 },
 "layers": [
 { "id": 0, "name": "Parcels" },
 { "id": 1, "name": "Buildings" }
 ],
 "tables": [
 { "id": 2, "name": "Owners" }
 ]
 "enableZDefaults": false
 }
 
 
 
 */

@end
