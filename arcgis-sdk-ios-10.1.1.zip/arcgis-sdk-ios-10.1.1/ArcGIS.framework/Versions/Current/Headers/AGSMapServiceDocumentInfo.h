/*
 COPYRIGHT 2013 ESRI
 
 TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
 Unpublished material - all rights reserved under the
 Copyright Laws of the United States and applicable international
 laws, treaties, and conventions.
 
 For additional information, contact:
 Environmental Systems Research Institute, Inc.
 Attn: Contracts and Legal Services Department
 380 New York Street
 Redlands, California, 92373
 USA
 
 email: contracts@esri.com
 */

/** @file AGSMapServiceDocumentInfo.h */ //Required for Globals API doc

#pragma mark -

/** @brief Information about the backing document for an ArcGIS Server map service.
 
 @define{AGSMapServiceDocumentInfo.h, ArcGIS}
 @agssince{10.2, 10.2}
 */

@interface AGSMapServiceDocumentInfo : NSObject <AGSCoding>

@property (nonatomic, copy) NSString *author;
@property (nonatomic, copy) NSString *category;
@property (nonatomic, copy) NSString *comments;
@property (nonatomic, copy) NSString *credits;
@property (nonatomic, copy) NSArray *keywords;
@property (nonatomic, copy) NSString *subject;
@property (nonatomic, copy) NSString *title;

@end
