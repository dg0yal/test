/*
 COPYRIGHT 2013 ESRI
 
 TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
 Unpublished material - all rights reserved under the
 Copyright Laws of the United States and applicable international
 laws, treaties, and conventions.
 
 For additional information, contact:
 Environmental Systems Research Institute, Inc.
 Attn: Contracts and Legal Services Department
 380 New York Street
 Redlands, California, 92373
 USA
 
 email: contracts@esri.com
 */

@class AGSGDBLocalFeatureTable;
@class AGSGeometry;
@protocol AGSFeature;
@protocol AGSInfoTemplateDelegate;

/** @file AGSFeature.h */ //Required for Globals API doc

/** @brief
 
 @define{AGSGDBFeature.h, ArcGIS}
 @since 
 */
@interface AGSGDBFeature : NSObject <AGSFeature>

@property (nonatomic, weak, readonly) AGSGDBLocalFeatureTable *table;

-(NSString*)shortDescription;

/**
 designated initializer
 */
-(id)initWithTable:(AGSGDBLocalFeatureTable*)table;

#pragma mark AGSFeature

@property (nonatomic, strong, readwrite) AGSGeometry *geometry;

-(NSDictionary*)allAttributes;
-(void)setAttributes:(NSDictionary*)attributes;
-(BOOL)hasAttributeForKey:(NSString*)key;
-(id)attributeForKey:(NSString*)key;
-(id)safeAttributeForKey:(NSString*)key;
-(void)setAttribute:(id)value forKey:(NSString*)key;

@end
