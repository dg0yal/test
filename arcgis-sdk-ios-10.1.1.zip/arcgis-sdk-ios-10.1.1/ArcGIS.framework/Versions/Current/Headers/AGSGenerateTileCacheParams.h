/*
 COPYRIGHT 2013 ESRI
 
 TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
 Unpublished material - all rights reserved under the
 Copyright Laws of the United States and applicable international
 laws, treaties, and conventions.
 
 For additional information, contact:
 Environmental Systems Research Institute, Inc.
 Attn: Contracts and Legal Services Department
 380 New York Street
 Redlands, California, 92373
 USA
 
 email: contracts@esri.com
 */

#import <Foundation/Foundation.h>
@class AGSGeometry;

/** @file AGSGenerateTileCacheParams.h */ //Required for Globals API doc

/** @brief
 
 @define{AGSGenerateTileCacheParams.h, ArcGIS}
 @since
 */

@interface AGSGenerateTileCacheParams : NSObject

@property (nonatomic, copy) NSArray *levelsOfDetail;

@property (nonatomic, strong) AGSGeometry *areaOfInterest;

-(id)initWithLevelsOfDetail:(NSArray*)lods areaOfInterest:(AGSGeometry*)aoi;

@end
