/*
 COPYRIGHT 2013 ESRI
 
 TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
 Unpublished material - all rights reserved under the
 Copyright Laws of the United States and applicable international
 laws, treaties, and conventions.
 
 For additional information, contact:
 Environmental Systems Research Institute, Inc.
 Attn: Contracts and Legal Services Department
 380 New York Street
 Redlands, California, 92373
 USA
 
 email: contracts@esri.com
 */

#import <Foundation/Foundation.h>

/** @file AGSGDBLayerQuery.h */ //Required for Globals API doc

/** @brief
 
 @define{AGSGDBLayerQuery.h, ArcGIS}
 @since 
 */
@interface AGSGDBLayerQuery : NSObject

/**
 @agssince{10.2, 10.2}
 */
@property (nonatomic, assign) NSUInteger layerId;

/*
 where: Defines an attribute query for a layer or table. The default is no where clause.
 useGeometry: Determines whether or not to apply the geometry for the layer. The default is true. If set to false, features from the layer that intersect the geometry are not added.
 includeRelated: Determines whether or not to add related rows. The default is true. Value true is honored only for queryOption = none. This is only applicable if your data has relationship classes.
 queryOption: Defines whether and how filters will be applied to a layer. The queryOption is new at 10.2. See the compatibility notes topic for more information.
 Values: <none | useFilter | all>
 When the value is none, no features are returned based on where and filter geometry. If includeRelated is false, no features are returned. If includeRelated is true, features in this layer (that are related to the features in other layers in the replica) are returned.
 When the value is useFilter, features that satisfy filtering based on geometry and where are retuned. Value of includeRelated is ignored.
 When the value is all, all the features from the layer are returned. All other parameters for the layer query are ignored.
 Syntax: layerQueries={ Layer_or_tableID1 : {"where":"attribute query" , "useGeometry" : true | false, "includeRelated" : true | false}, Layer_or_tableID2: {.}}
 Examples:
 layerQueries={"1":{"useGeometry " : false}}
 layerQueries={"0":{"where" : "requires_inspection = True" }, "1":{"useGeometry " : false}}
 layerQueries={"0":{"useGeometry " : false, "includeRelated" : false}}, "1":{"useGeometry " : false}}
 */


@property (nonatomic, copy) NSString *where;

@property (nonatomic, assign) BOOL useGeometry;

@property (nonatomic, assign) BOOL includeRelated;

/*
 Values: <none | useFilter | all>
 When the value is none, no features are returned based on where and filter geometry. If includeRelated is false, no features are returned. If includeRelated is true, features in this layer (that are related to the features in other layers in the replica) are returned.
 When the value is useFilter, features that satisfy filtering based on geometry and where are retuned. Value of includeRelated is ignored.
 When the value is all, all the features from the layer are returned. All other parameters for the layer query are ignored.
 */
@property (nonatomic, assign) AGSGDBQueryOption option;

@end
