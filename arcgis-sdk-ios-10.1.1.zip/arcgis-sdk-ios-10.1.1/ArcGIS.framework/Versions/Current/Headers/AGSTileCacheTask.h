/*
 COPYRIGHT 2013 ESRI
 
 TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
 Unpublished material - all rights reserved under the
 Copyright Laws of the United States and applicable international
 laws, treaties, and conventions.
 
 For additional information, contact:
 Environmental Systems Research Institute, Inc.
 Attn: Contracts and Legal Services Department
 380 New York Street
 Redlands, California, 92373
 USA
 
 email: contracts@esri.com
 */

#import "AGSTask.h"
#import "AGSTileCacheServiceInfo.h"
#import "AGSGenerateTileCacheParams.h"

/** @file AGSTileCacheTask.h */ //Required for Globals API doc

/** @brief
 
 @define{AGSTileCacheTask.h, ArcGIS}
 @since
 */

@interface AGSTileCacheTask : AGSTask

@property (nonatomic, assign) NSTimeInterval interval;

@property (nonatomic, strong) AGSTileCacheServiceInfo *tiledServiceInfo;

@property (nonatomic, copy) void (^loadCompletion)(NSError *error);

-(NSOperation*)generateTileCacheWithParameters:(AGSGenerateTileCacheParams *)params
                                    jobStarted:(AGSTileCacheTaskJobStartedBlock)jobStartedBlock;

-(void)generateTileCacheWithParameters:(AGSGenerateTileCacheParams *)params
                            jobStarted:(AGSTileCacheTaskJobStartedBlock)jobStartedBlock
                                status:(AGSTileCacheTaskCombinedStatusBlock)statusBlock;

-(void)scheduleStatusChecksForJobId:(NSString *)jobId
                             status:(AGSTileCacheTaskCombinedStatusBlock)statusBlock;

-(void)unscheduleStatusChecksForJobId:(NSString *)jobId;

-(void)cancelForJobId:(NSString *)jobId
           completion:(void (^)(NSError *error))completionBlock;

-(void)checkStatusForJobId:(NSString *)jobId
                    status:(AGSTileCacheTaskCombinedStatusBlock)statusBlock;


-(NSOperation*)fetchTileCacheAtURL:(NSURL *)tileCacheUrl
                        saveToPath:(NSString *)path
                        completion:(void (^)(NSError *error))completionBlock;

-(id)initWithURL:(NSURL *)url credential:(AGSCredential *)cred;



-(void)estimateSizeWithParameters:(AGSGenerateTileCacheParams *)params
                           status:(AGSTileCacheTaskCombinedStatusBlock)statusBlock;


@end
