//
//  AGSGDBFeatureLayer.h
//  ArcGISRT
//
//  Created by Ryan Olson on 4/25/13.
//
//

@class AGSLayer;
@class AGSQuery;
@class AGSGDBFeature;
@class AGSGDBFeatureCursor;
@class AGSGDBLocalFeatureTable;
@class AGSGDBGeodatabase;
@class AGSSymbol;
@protocol AGSFeatureSourceInfo;
@protocol AGSInfoTemplateDelegate;

@interface AGSGDBFeatureLayer : AGSLayer <AGSHitTestable>

-(id)initWithFeatureTable:(AGSGDBLocalFeatureTable*)table;

@property (nonatomic, strong, readonly) AGSGDBLocalFeatureTable *table;
@property (nonatomic, strong, readonly) AGSGDBGeodatabase *geodatabase;

@property (nonatomic, assign, readwrite) BOOL showLabels;

/** Property that determines if the layer allows it to be hit tested or if it is bypassed.
 @agssince{10.2, 10.2}
 */
@property (nonatomic, assign) BOOL allowHitTest;

/** Property that determines if the layer allows callouts to be shown for its features.
 @agssince{10.2, 10.2}
 */
@property (nonatomic, assign) BOOL allowCallout;

/** The symbol to use for drawing selected features
 @agssince{10.2, 10.2}
 */
@property (nonatomic, strong, readwrite) AGSSymbol *selectionSymbol;

/** The color to use for drawing a halo around selected features
 @agssince{10.2, 10.2}
 */
@property (nonatomic, copy) AGSColor *selectionColor;

/** Delegate that allows the layer to react to when a callout is shown for one of it's features.
 @agssince{10.2, 10.2}
 */
@property (nonatomic, weak) id<AGSLayerCalloutDelegate> calloutDelegate;

/** Selects or un-selects the feature.
 Features with selection enabled will be drawn using #selectionSymbol.
 If #selectionSymbol is not specified, then #selectionColor will be used to draw a halo around the feature.
 @param selected If YES, feature will be selected. Else it will be un-selected
 @param feature
 @agssince{10.2, 10.2}
 */
-(void)setSelected:(BOOL)selected forFeature:(AGSGDBFeature*)feature;

/** Returns whether a given feature is selected or not.
 Features with selection enabled will be drawn using #selectionSymbol.
 If #selectionSymbol is not specified, then #selectionColor will be used to draw a halo around the feature.
 @param feature
 @agssince{10.2, 10.2}
 */
-(BOOL)isFeatureSelected:(AGSGDBFeature*)feature;

/** Clears selection on all features
 @agssince{10.2, 10.2}
 */
-(void)clearSelection;

/** An array of @c AGSGDBFeature objects representing features that have selection enabled
 Features with selection enabled will be drawn using #selectionSymbol.
 If #selectionSymbol is not specified, then #selectionColor will be used to draw a halo around the feature.
 @agssince{10.2, 10.2}
 */
-(NSArray*)selectedFeatures;
@end
