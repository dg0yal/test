/*
 COPYRIGHT 2013 ESRI
 
 TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
 Unpublished material - all rights reserved under the
 Copyright Laws of the United States and applicable international
 laws, treaties, and conventions.
 
 For additional information, contact:
 Environmental Systems Research Institute, Inc.
 Attn: Contracts and Legal Services Department
 380 New York Street
 Redlands, California, 92373
 USA
 
 email: contracts@esri.com
 */

#import <Foundation/Foundation.h>
@class AGSGeometry;

/** @file AGSGDBGenerateParameters.h */ //Required for Globals API doc

/** @brief
 
 @define{AGSGDBGenerateParameters.h, ArcGIS}
 @agssince{10.2, 10.2}
 */
@interface AGSGDBGenerateParameters : NSObject

/** The name of the replica.
@agssince{10.2, 10.2}
*/
@property (nonatomic, copy) NSString *name;

/**
 @agssince{10.2, 10.2}
 */
@property (nonatomic, strong) AGSGeometry *extent;

/** Array of layer ids as NSNumber objects.
 @agssince{10.2, 10.2}
 */
@property (nonatomic, copy) NSArray *layerIds;

/** Array of AGSGDBLayerQuery objects.
 @agssince{10.2, 10.2}
 */
@property (nonatomic, copy) NSArray *queries;

/**
 @agssince{10.2, 10.2}
 */
@property (nonatomic, assign) BOOL returnAttachments;

/**
 @agssince{10.2, 10.2}
 */
-(id)initWithExtent:(AGSGeometry*)extent layerIds:(NSArray*)layerIds;

@end
